#!/usr/bin/python


from synth import play_synth
import _thread
import time
from parser import open_file

# Define a function for the thread
def print_time( threadName, delay):
   count = 0
   while count < 5:
      time.sleep(delay)
      count += 1
      print ("%s: %s" % ( threadName, time.ctime(time.time()) ))

# Create two threads as follows
try:
	arr = open_file('Toccata.synth')
	# _thread.start_new_thread(play_synth(0, arr) )
	# _thread.start_new_thread( play_synth(1, arr) )
	# _thread.start_new_thread(play_synth(3, arr) )
	# _thread.start_new_thread( play_synth(4, arr) )
	_thread.start_new_thread(play_synth(5, arr) )
	_thread.start_new_thread(play_synth(6, arr))
	_thread.start_new_thread( play_synth(7, arr))
	_thread.start_new_thread(play_synth(8,  arr))
	_thread.start_new_thread( play_synth(9,  arr))
	_thread.start_new_thread(play_synth(10,  arr))
	_thread.start_new_thread(play_synth(11,  arr))
	_thread.start_new_thread( play_synth(12,  arr))
	# _thread.start_new_thread(play_synth(13, 'Toccata.synth') )
	# _thread.start_new_thread( play_synth(14, 'Toccata.synth') )
	# _thread.start_new_thread(play_synth(155, 'Toccata.synth') )
except:
   print ("Error: unable to start thread")

while 1:
   pass